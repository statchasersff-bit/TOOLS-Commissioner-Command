# StatChasers Design Kit

Drop-in style foundation for a React + Tailwind + shadcn project.
Replicates the navy/gold dark-mode theme from StatChasers Dynasty Command.

---

## What's Included

```
src/
  index.css               ← CSS custom properties (colors, shadows, dark mode)
  tailwind.config.ts      ← Tailwind theme mapping those CSS vars
  lib/
    utils.ts              ← cn() helper (clsx + tailwind-merge)
  components/
    KpiCard.tsx           ← Stat card with icon, value, subtitle, skeleton
    SectionHeader.tsx     ← Section title with gold underline accent
    ThemeToggle.tsx       ← Dark/light toggle with localStorage persistence
    ui/
      card.tsx            ← Card, CardHeader, CardContent, CardFooter
      badge.tsx           ← Badge with default/secondary/outline/destructive variants
      button.tsx          ← Button with hover/active elevation system
      tooltip.tsx         ← Radix tooltip styled to the theme
```

---

## Setup Steps

### 1. Install dependencies

```bash
npm install tailwindcss tailwindcss-animate @tailwindcss/typography
npm install clsx tailwind-merge
npm install class-variance-authority
npm install lucide-react
npm install @radix-ui/react-tooltip @radix-ui/react-slot
```

### 2. Copy files

- Replace your `tailwind.config.ts` with the one from this kit (or merge the `theme.extend` block in).
- Replace (or merge) your `src/index.css` with the one from this kit.
- Drop the `src/lib/utils.ts`, `src/components/ui/`, and `src/components/` files into your project.

### 3. Configure path aliases

In your `tsconfig.json` (or `vite.config.ts`), add:

```json
{
  "compilerOptions": {
    "paths": {
      "@/*": ["./src/*"]
    }
  }
}
```

For Vite specifically:

```ts
import { defineConfig } from "vite";
import path from "path";

export default defineConfig({
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
});
```

### 4. Default to dark mode

In your root component or `main.tsx`, add this before React mounts so there's no flash:

```ts
const saved = localStorage.getItem("theme");
document.documentElement.classList.toggle("dark", saved !== "light");
```

---

## Brand Tokens

| Token   | Value     | Use                          |
|---------|-----------|------------------------------|
| Navy    | `#0b3a7a` | Primary buttons, icons, links |
| Gold    | `#d4af37` | Accent underlines, highlights |

Use them directly in Tailwind:
```tsx
<span className="text-[#0b3a7a] dark:text-blue-400" />
<span className="bg-[#d4af37]" />
```

---

## Component Usage

### KpiCard
```tsx
import { KpiCard } from "@/components/KpiCard";
import { Trophy } from "lucide-react";

<KpiCard label="Win Rate" value="67%" icon={Trophy} subtitle="12W - 6L" trend="up" />
```

### SectionHeader
```tsx
import { SectionHeader } from "@/components/SectionHeader";

<SectionHeader title="League Overview" subtitle="Your standings across all leagues" />
```

### ThemeToggle
```tsx
import { ThemeToggle } from "@/components/ThemeToggle";

<ThemeToggle />  // drop anywhere in your nav bar
```

---

## Elevation System

The CSS includes a hover/active elevation utility used throughout the tool:

```tsx
<div className="hover-elevate">...</div>      // subtle lift on hover
<div className="hover-elevate-2">...</div>    // stronger lift on hover
<div className="active-elevate-2">...</div>   // lift on click
```

The `Button` and `Badge` components apply these automatically.
