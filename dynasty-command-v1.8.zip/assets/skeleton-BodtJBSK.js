import{j as t,g as n}from"./index-C4jRUBCQ.js";function m({className:e,...s}){return t.jsx("div",{className:n("animate-pulse rounded-md bg-muted",e),...s})}export{m as S};
