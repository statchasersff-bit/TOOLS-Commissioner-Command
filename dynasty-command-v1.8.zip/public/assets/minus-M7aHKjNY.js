import{c as s}from"./index-4SE7UTsx.js";const c=s("Minus",[["path",{d:"M5 12h14",key:"1ays0h"}]]);export{c as M};
