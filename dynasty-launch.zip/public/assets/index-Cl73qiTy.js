function t(r){return r===1?"1st":r===2?"2nd":r===3?"3rd":`${r}th`}function n(r){return`${r.year} ${t(r.round)}`}export{n as f};
