import{c as s}from"./index-C_I1mGMS.js";const c=s("Minus",[["path",{d:"M5 12h14",key:"1ays0h"}]]);export{c as M};
